function displayFields(form,customHTML){
	customHTML.append('<script type="text/javascript">'+ '$(document).ready(function(){'); //carregar informações após o HTML carregar
	customHTML.append('console.log("USANDO CUSTOMHTML")'); // Acesso à console de depuração do navegador
	customHTML.append('});'+'</script>') //Função para carregar dados na tela  
	
	function api_usuarioCorrente (){
		return fluigAPI.getUserService().getCurrent();
		}
	
	log.info ("##############" + api_usuarioCorrente());
	
	//coleta de dados
	var atual = getValue("WKNumState");
	var user = api_usuarioCorrente().getFullName();
	var email = api_usuarioCorrente().getEmail();
	
	//atividades
	var inicio = "7";
	var analisar_gestor = "8";
	var analisar_financ = "25";
	var realiza_compra = "32";
	
	//Arrays
	
	var esconder = [];
	
	if(atual == inicio || atual == 0){
		form.setValue ("solicitante",user)
		form.setValue ("email", email)
		esconder.push ("nav_dados_integra")
		esconder.push ("nav_dados_aprov")
	}
		
	if(atual == analisar_gestor){
		esconder.push ("nav_dados_integra")
		
		
	}
	
	if(atual == analisar_financ){
		esconder.push ("nav_dados_integra")
		
		
	}
	
	for (var i=0; i<esconder.length; i++){
		form.setVisibleById(esconder[i],false);
	}
}