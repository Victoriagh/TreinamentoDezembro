function validateForm(form){
	
	
	//coleta de dados
	var atual = getValue("WKNumState")
	
	var inicio = "3";
	var analisar_gestor = "8";
	var analisa_financ = "15";
	
	//Arrays
	
	var valida = [];
	
	if (atual == inicio){
		valida.push("nome");
		
	}
	
		
	
	for (var i=0; i<valida.length; i++){
		if(form.getValue(valida[i])== null||form.getValue(valida[i]).trim()==""){
				throw("O campo" +valida[i]+ "precisa ser preenchido");
	}
}

}