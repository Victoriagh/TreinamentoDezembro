console.log("estou usando js")

function calcula(id){
	var pos= id.split("___");
	var index=pos[1];
	var calc= $("#quantidade_prod___"+index).val()* $("#valUnit_prod___"+index).val()
	$("#valTotal_prod___"+index).val(calc);
	calculaTotal();

}

function fnCustomDelete(oElement){
    // Chamar a funcao padrao para eliminar a linha
    fnWdkRemoveChild(oElement);
    
	calculaTotal();
}

function calculaTotal(){
	var totalLinhas = $("#tb_produtos tbody tr:visible").length;
	var linhas = $("#tb_produtos tbody tr:visible");
	var total = 0;

	for(var i = 0; i < totalLinhas; i++){
	    var valorLinha = $(linhas[i]).find("input[name^=valTotal_prod___]").val();
	    if(valorLinha != ""){
	        total +=  parseFloat($(linhas[i]).find("input[name^=valTotal_prod___]").val());
	    }
	}

	$("#total_produto").val(total);
}