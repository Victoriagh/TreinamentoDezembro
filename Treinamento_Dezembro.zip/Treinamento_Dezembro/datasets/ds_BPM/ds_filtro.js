function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	
	var filtroGrupo = DatasetFactory.createConstraint ('colleagueGroupPK.groupId', 'Gestores', 'Gestores', ConstraintType.MUST);
	var dataset = DatasetFactory.getDataset('colleagueGroup', null, new Array(filtroGrupo), null);
	
	return dataset;

}function onMobileSync(user) {

}